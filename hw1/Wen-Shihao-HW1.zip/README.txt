External libraries used：   import sys
                            import dns.resolver
                            import time
                            from datetime import datetime

Instructions on how to run my programs：
    PartA：$ python mydigA.py [Domain Name] [type]
        E.g:python mydigA.py www.cnn.com. A

    PartB：$ python mydigB.py [Domain Name] [type]
        E.g:python mydigB.py www.cnn.com. A